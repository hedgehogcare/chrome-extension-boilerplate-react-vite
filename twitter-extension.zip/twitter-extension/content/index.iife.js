(function(){"use strict";function o(){console.log("content script - sampleFunction() called from another module")}console.log("content script loaded"),o()})();
